//
//  ViewController.swift
//  TableViewPractice2
//
//  Created by 유철원 on 5/24/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

