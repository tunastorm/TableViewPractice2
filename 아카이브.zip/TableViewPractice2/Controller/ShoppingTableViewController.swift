//
//  ShoppingTableViewController.swift
//  TableViewPractice2
//
//  Created by 유철원 on 5/24/24.
//

import UIKit


class ShoppingTableViewController: UITableViewController {
        
    var searchBarTitles: [String] = ["무엇을 구매하실 건가요?", "추가"]
    
    var sectionList = SectionList()
    
    var todoList = ToDoList()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "쇼핑"
        tableView.rowHeight = 60
        tableView.separatorStyle = .singleLine
        tableView.separatorColor = .gray
        tableView.backgroundColor = .white
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return sectionList.getSectionList().count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return sectionList.getSection(at: section).rowSize
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let section = indexPath.section
        let row = indexPath.row
    
        var cell = UITableViewCell()
        if section == 0 {
            cell = tableView.dequeueReusableCell(withIdentifier: "SearchTableViewCell"
                                                 ,for: indexPath) as! SearchTableViewCell
            cell = setSerchViewCell(cell as! SearchTableViewCell)
        } else if section == 1 {
            cell = tableView.dequeueReusableCell(withIdentifier: "ShoppingTableViewCell",
                                                    for: indexPath) as! ShoppingTableViewCell
            cell = setShoppingTableViewCells(cell as! ShoppingTableViewCell, section: section, row: row)
        }
        
        cell.selectionStyle = .default
        cell.backgroundColor = .systemGray6
        cell.tintColor = .black
        cell.textLabel?.font = .systemFont(ofSize: 12)
        
        return cell
    }
    
    func setSerchViewCell(_ cell: SearchTableViewCell) -> SearchTableViewCell{
        cell.searchTextField.placeholder = searchBarTitles[0]
        cell.searchTextField.backgroundColor = .clear
        cell.searchTextField.borderStyle = .none
        
        cell.searchButton.layer.cornerRadius = cell.searchButton.frame.height * 0.1
        cell.searchButton.setTitle(searchBarTitles[1], for: .normal)
        cell.searchButton.backgroundColor = .lightGray
        
        
        return cell
    }
    
    func setShoppingTableViewCells(_ cell : ShoppingTableViewCell, section: Int, row index: Int) -> ShoppingTableViewCell{
        let row = todoList.getTodo(at: index)
        
        cell.todoLabel.text = row.action
        let doneName = row.isDone ? "checkmark.square.fill":"checkmark.square"
        let bookmarkName = row.bookmark ? "star.fill" : "star"
        
        let doneImage = UIImage(systemName: doneName)
        let bookmarkImage = UIImage(systemName: bookmarkName)
        
        cell.isDoneButton.setTitle("", for: .normal)
        cell.isDoneButton.setImage(doneImage, for: .normal)
        cell.isDoneButton.tag = index
        cell.isDoneButton.addTarget(self, action: #selector(isDoneButtonClicked), for: .touchUpInside)
        
        cell.bookmarkButton.setTitle("", for: .normal)
        cell.bookmarkButton.tag = index
        cell.bookmarkButton.setImage(bookmarkImage, for: .normal)
        cell.bookmarkButton.addTarget(self, action: #selector(bookmarkButtonClicked), for: .touchUpInside)
        
        return cell
    }
    
    // Event: Push Up Inside
    @objc func bookmarkButtonClicked(_ sender: UIButton) {
        
        todoList.updateBookmark(at: sender.tag)
        
        guard let section = tableView.indexPathForSelectedRow?.section else {
            print("section 값 없음")
            return
        }
    
        tableView.reloadRows(at:[IndexPath(row: sender.tag, section:1)], with: .none)
    }
    
    // Event: Push Up Inside
    @objc func isDoneButtonClicked(_ sender: UIButton) {
        
        todoList.updateIsDone(at: sender.tag)
        
        guard let section = tableView.indexPathForSelectedRow?.section else {
            print("section 값 없음")
            return
        }
        tableView.reloadRows(at:[IndexPath(row: sender.tag, section:1)], with: .none)
    }


}
