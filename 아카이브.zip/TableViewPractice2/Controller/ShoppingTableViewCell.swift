//
//  ShoppingTableViewCell.swift
//  TableViewPractice2
//
//  Created by 유철원 on 5/24/24.
//

import UIKit

class ShoppingTableViewCell: UITableViewCell {
    
    @IBOutlet weak var isDoneButton: UIButton!
    
    @IBOutlet weak var bookmarkButton: UIButton!
    
    @IBOutlet weak var todoLabel: UILabel!
    
}
