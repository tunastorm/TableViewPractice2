//
//  SearchTableViewCell.swift
//  TableViewPractice2
//
//  Created by 유철원 on 5/24/24.
//

import UIKit

class SearchTableViewCell: UITableViewCell {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var searchButton: UIButton!
    
}
    
